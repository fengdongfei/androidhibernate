package com.hkcts.passportsearch.model;

import java.util.Date;

import com.ydl.ahibernate.annotation.Column;
import com.ydl.ahibernate.annotation.Id;
import com.ydl.ahibernate.annotation.Table;

//此处没有加Table属性,它是其他类的基类,本类中用@Column注解的字段在子类中同样会被创建到表中.
@Table(name = "gzl_user")
public class gzl_user {
	@Id
	@Column(name = "id")
	private int id; // 主键,int类型,数据库建表时此字段会设为自增长

	@Column(name = "realName", length = 10)
	private String realName; // 护照编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "userCode", length = 50)
	private String userCode; // 护照芯片编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "phone", length = 15)
	private String phone; // 名字长度一般不会超过20个字符吧,length=20数据字段的长度是20
	@Column(name = "idCard", length = 24)
	private Date idCard; // 名字长度一般不会超过20个字符吧,length=20数据字段的长度是20

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the realName
	 */
	public String getRealName() {
		return realName;
	}

	/**
	 * @param realName
	 *            the realName to set
	 */
	public void setRealName(String realName) {
		this.realName = realName;
	}

	/**
	 * @return the userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode
	 *            the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the idCard
	 */
	public Date getIdCard() {
		return idCard;
	}

	/**
	 * @param idCard
	 *            the idCard to set
	 */
	public void setIdCard(Date idCard) {
		this.idCard = idCard;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "gzl_user [id=" + id + ", realName=" + realName + ", userCode="
				+ userCode + ", phone=" + phone + ", idCard=" + idCard + "]";
	}

	// //假设您开始时没有此属性,程序开发中才想到此属性,去掉代码注释试试吧,数据库增删改查不用修改任何代码哦.
	// @Column(name = "sex")
	// private String sex;

	// // 有些字段您可能不希望保存到数据库中,不用@Column注释就不会映射到数据库.
	// private String noSaveFild;

}
