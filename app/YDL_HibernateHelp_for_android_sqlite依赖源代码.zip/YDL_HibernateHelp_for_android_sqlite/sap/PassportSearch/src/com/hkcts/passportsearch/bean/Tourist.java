package com.hkcts.passportsearch.bean;

/**
 * 封装游客信息的类
 * 
 * @author 袁东亮
 * 
 */
public class Tourist {
	private String passportId;
	private String Name;
	private String phoneNumber;
	private String IDNumber;
	private String integral;
	private int dc;

	public Tourist() {
	}

	public Tourist(String passportId, String Name, String phoneNumber,
			String IDNumber) {
		this.passportId = passportId;
		this.Name = Name;
		this.phoneNumber = phoneNumber;
		this.IDNumber = IDNumber;
	}

	/**
	 * @return the passportId
	 */
	public String getPassportId() {
		return passportId;
	}

	/**
	 * @param passportId
	 *            the passportId to set
	 */
	public void setPassportId(String passportId) {
		this.passportId = passportId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return Name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		Name = name;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber
	 *            the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the iDNumber
	 */
	public String getIDNumber() {
		return IDNumber;
	}

	/**
	 * @param iDNumber
	 *            the iDNumber to set
	 */
	public void setIDNumber(String iDNumber) {
		IDNumber = iDNumber;
	}

	/**
	 * @return the integral
	 */
	public String getIntegral() {
		return integral;
	}

	/**
	 * @param integral
	 *            the integral to set
	 */
	public void setIntegral(String integral) {
		this.integral = integral;
	}

	/**
	 * @return the dc
	 */
	public int getDc() {
		return dc;
	}

	/**
	 * @param dc
	 *            the dc to set
	 */
	public void setDc(int dc) {
		this.dc = dc;
	}

}
