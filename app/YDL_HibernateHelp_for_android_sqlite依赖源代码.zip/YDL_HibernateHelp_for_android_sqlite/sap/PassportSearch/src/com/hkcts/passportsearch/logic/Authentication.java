package com.hkcts.passportsearch.logic;

import java.util.List;

import android.content.Context;

import com.hkcts.passportsearch.dao.impl.gzl_passportDaoImpl;
import com.hkcts.passportsearch.model.gzl_passport;

public class Authentication {
	private Context context;

	public Authentication(Context context) {
		this.context = context;
	}

	public gzl_passportDaoImpl gzl_passportDao() {
		return new gzl_passportDaoImpl(context);
	}

	// 护照状态,0-未激活，1-正常，2-过期，3-禁用，5-一个护照在一个景区一天只能使用一次，9-假护照
	// uc：用户编码ic：身份证号rn:真实姓名ph:电话
	public int AuthenticationPassPortState(String viewSpotCode,
			String passportCode) {
		System.out.println("viewSpotCode" + viewSpotCode + "passportCode"
				+ passportCode);
		if (viewSpotCode == null || passportCode == null) {

			return 99;
		} else {

			List<gzl_passport> passportMap = gzl_passportDao().rawQuery(
					"select * from gzl_passport where  passportCode= ? ",
					new String[] { passportCode });

			if (passportMap == null || passportMap.size() < 1
					|| passportMap.get(0) == null
					|| "".equals(passportMap.get(0))) { // 查不到护照，说明护照未激活
				// out.print("{'s':0}");
				return 0;
			} else {
				return 1;
			}

			// List<Map<String, String>> passportTimeMap = gzl_passportDao
			// .query2MapList(
			// "select lastTime from gzl_passport_recording where passportCode=? and viewSpotCode=?",
			// new String[] { passportCode, passportCode });
			// if (passportTimeMap != null && passportTimeMap.get(0) != null
			// && !"".equals(passportTimeMap.get(0).get("lasttime"))) { // 查到记录
			//
			// String lastTime = passportTimeMap.get(0).get("lasttime")
			// .toString();
			// Date currentTime = new Date();
			// Date lastTimeD = DateUtils.formatStr2Date(lastTime);
			// if (DateUtils.caculate2Days(currentTime, lastTimeD) <= 1) {
			// return 5;
			// }
			// }
			/* 验证护照状态 */
			// String passportStatus =
			// passportMap.get(0).get("status").toString();
			// String userCode = passportMap.get(0).get("usercode").toString();
			// System.out.println(passportStatus);

			// return 0;
		}

	}
}
