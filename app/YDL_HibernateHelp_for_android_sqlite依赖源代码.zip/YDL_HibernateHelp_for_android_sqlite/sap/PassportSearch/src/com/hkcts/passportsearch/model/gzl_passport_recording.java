package com.hkcts.passportsearch.model;

import java.util.Date;

import com.ydl.ahibernate.annotation.Column;
import com.ydl.ahibernate.annotation.Id;
import com.ydl.ahibernate.annotation.Table;

//此处没有加Table属性,它是其他类的基类,本类中用@Column注解的字段在子类中同样会被创建到表中.
@Table(name = "gzl_passport_recording")
public class gzl_passport_recording {
	@Id
	@Column(name = "id")
	private int id; // 主键,int类型,数据库建表时此字段会设为自增长

	@Column(name = "passportCode", length = 50)
	private String passportCode; // 护照编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "passportChipCode", length = 50)
	private String passportChipCode; // 护照芯片编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "lastTime", type = "datetime")
	private Date lastTime; // 名字长度一般不会超过20个字符吧,length=20数据字段的长度是20
	@Column(name = "viewSpotCode", length = 50)
	private String viewSpotCode; // 名字长度一般不会超过20个字符吧,length=20数据字段的长度是20

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the passportCode
	 */
	public String getPassportCode() {
		return passportCode;
	}

	/**
	 * @param passportCode
	 *            the passportCode to set
	 */
	public void setPassportCode(String passportCode) {
		this.passportCode = passportCode;
	}

	/**
	 * @return the passportChipCode
	 */
	public String getPassportChipCode() {
		return passportChipCode;
	}

	/**
	 * @param passportChipCode
	 *            the passportChipCode to set
	 */
	public void setPassportChipCode(String passportChipCode) {
		this.passportChipCode = passportChipCode;
	}

	/**
	 * @return the lastTime
	 */
	public Date getLastTime() {
		return lastTime;
	}

	/**
	 * @param lastTime
	 *            the lastTime to set
	 */
	public void setLastTime(Date lastTime) {
		this.lastTime = lastTime;
	}

	/**
	 * @return the viewSpotCode
	 */
	public String getViewSpotCode() {
		return viewSpotCode;
	}

	/**
	 * @param viewSpotCode
	 *            the viewSpotCode to set
	 */
	public void setViewSpotCode(String viewSpotCode) {
		this.viewSpotCode = viewSpotCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "gzl_passport_recording [id=" + id + ", passportCode="
				+ passportCode + ", passportChipCode=" + passportChipCode
				+ ", lastTime=" + lastTime + ", viewSpotCode=" + viewSpotCode
				+ "]";
	}

	// //假设您开始时没有此属性,程序开发中才想到此属性,去掉代码注释试试吧,数据库增删改查不用修改任何代码哦.
	// @Column(name = "sex")
	// private String sex;

	// // 有些字段您可能不希望保存到数据库中,不用@Column注释就不会映射到数据库.
	// private String noSaveFild;

}
