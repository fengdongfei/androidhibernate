package com.hkcts.passportsearch.bean;

import android.widget.Button;
import android.widget.TextView;

/**
 * 优化ListView的viewHoder
 * 
 * @author 袁东亮
 * 
 */
public class ViewHoder {
	public TextView scenicName;
	public TextView scenicId;
	public Button settingButton;
}
