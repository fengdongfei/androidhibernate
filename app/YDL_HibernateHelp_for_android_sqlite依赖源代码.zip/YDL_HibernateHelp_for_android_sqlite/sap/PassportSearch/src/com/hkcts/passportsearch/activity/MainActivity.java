package com.hkcts.passportsearch.activity;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.http.Header;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hkcts.passportsearch.R;
import com.hkcts.passportsearch.bean.Tourist;
import com.hkcts.passportsearch.config.RequestCode;
import com.hkcts.passportsearch.config.RequestURl;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.xminnov.IvrJackAdapter;
import com.xminnov.IvrJackService;
import com.xminnov.IvrJackStatus;

/**
 * @author 主界面 6222023700029071596
 * 
 */
@SuppressLint({ "NewApi", "WorldReadableFiles" })
public class MainActivity extends Activity implements IvrJackAdapter,
		OnClickListener {
	private Context context;
	// private TextView scenicId = null;
	// private TextView txtUID = null;
	// private TextView txtBlock1 = null;
	// private TextView txtBlock2 = null;
	private ImageView imgPlugout = null;
	private TextView txtStatus = null;
	private TextView txtDate = null;
	private ProgressDialog pd;
	private boolean bSuccess;
	private String cMsg;
	private MyHandler handler = null;
	private byte[] data = new byte[32];
	private byte[] Data2_0 = new byte[16];
	// private boolean bReadBlock = false;
	// private boolean bCancel = false;
	IvrJackService reader = null;
	private AutoQureTag autoQureTag;
	private boolean isready;
	private TextView passportId_label;
	private TextView passportId_textView;
	private TextView name_label;
	private TextView name_textView;
	private TextView phoneNumber_label;
	private TextView phoneNumber_textView;
	private TextView IDNumber_label;
	private TextView IDNumber_textView;
	private TextView passportState_label;
	private TextView passportState_textView;
	private TextView integral_label;
	private TextView integral_textView;
	private TextView dctextView;
	private RelativeLayout passport_state_relativilayout;
	private RelativeLayout passport_info_relativelLayout;
	private Button scenicChoose_button;
	private byte[] block3_data = new byte[16];
	private TextView scenicName_textView;
	private SharedPreferences sp;
	private String passportId;
	private Button activate_button;
	private String responseResult;
	// private String appVsrsion = "android_version.json";
	private boolean menu_display = false;
	private PopupWindow menuWindow;
	private LayoutInflater inflater;
	@SuppressWarnings("unused")
	private LinearLayout mClose;
	private LinearLayout mCloseBtn;
	private View layout;

	public static MainActivity instance = null;

	// private Authentication authentication;

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		context = this;
		instance = this;
		//
		// try {
		// new NewVersion(this, RequestURl.AutoUpdate, appVsrsion)
		// .checkUpdateVersion();
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// //////////////////////创建本地数据库////////////////////////////viewSpotCodeSXJQ2passportCode0123456789101112131415
		// gzl_passportDaoImpl gzl_passportDao = new gzl_passportDaoImpl(
		// MainActivity.this);
		// gzl_passport passport = new gzl_passport();
		// passport.setPassportCode("0123456789101112131415");
		// passport.setPassportChipCode("0123456789101112131415");
		// passport.setPassportOpenTime(String.valueOf(new Date()));
		// passport.setPassportCloseTime(String.valueOf(new Date()));
		// passport.setPassportUserdNum(0);
		// passport.setStatus("-1");
		// passport.setUserCode("0123456789101112131415");
		// Long id = gzl_passportDao.insert(passport);
		// gzl_passport passport1 = new gzl_passport();

		// System.out.println(gzl_passportDao.get(id.intValue()));
		// //////////////////////////////////////////////////

		scenicName_textView = (TextView) findViewById(R.id.scenicName_textView);
		autoQureTag = new AutoQureTag();
		scenicChoose_button = (Button) findViewById(R.id.chooose_sicenic_button);
		scenicChoose_button.setOnClickListener(this);
		passport_state_relativilayout = (RelativeLayout) findViewById(R.id.passport_state_relativilayout);
		passport_info_relativelLayout = (RelativeLayout) findViewById(R.id.passport_info_relativelLayout);
		passportId_label = (TextView) findViewById(R.id.passportId_label);
		passportId_textView = (TextView) findViewById(R.id.passportId_textView);
		name_label = (TextView) findViewById(R.id.name_label);
		name_textView = (TextView) findViewById(R.id.name_textView);
		phoneNumber_label = (TextView) findViewById(R.id.phoneNumber_label);
		phoneNumber_textView = (TextView) findViewById(R.id.phoneNumber_textView);
		IDNumber_label = (TextView) findViewById(R.id.IDNumber_label);
		IDNumber_textView = (TextView) findViewById(R.id.IDNumber_textView);
		passportState_label = (TextView) findViewById(R.id.passportState_label);
		passportState_textView = (TextView) findViewById(R.id.passportState_textView);
		activate_button = (Button) findViewById(R.id.activate_button);
		integral_label = (TextView) findViewById(R.id.integral_label);
		integral_textView = (TextView) findViewById(R.id.integral_textView);
		dctextView = (TextView) findViewById(R.id.dctextView);
		txtStatus = (TextView) findViewById(R.id.txtStatus);
		txtDate = (TextView) findViewById(R.id.txtDate);
		// lblUID = (TextView) findViewById(R.id.phoneNumber_textView);
		// lblBlock1 = (TextView) findViewById(R.id.TextView03);
		// lblBlock2 = (TextView) findViewById(R.id.TextView02);
		// chkReadBlock = (CheckBox) findViewById(R.id.chkReadBlock);
		imgPlugout = (ImageView) findViewById(R.id.imgPlugout);
		// scenicId = (TextView) findViewById(R.id.scenicId_textView);
		//
		// writer_button = (Button) findViewById(R.id.writer_button);
		handler = new MyHandler(this);
		// writer_button.setOnClickListener(new btnwritr_OnClick());
		// btnQuery.setOnClickListener(new btnQuery_Click());
		reader = new IvrJackService();
		autoQureTag = new AutoQureTag();
		reader.open(this, this);
		sp = getSharedPreferences("haveScenicId", MODE_WORLD_READABLE);
		alertDialog = showChooseDialog();
		checkScenicId();
	}

	private String scenicId;
	private String scenicName;

	/**
	 * 启动时检测是否选择了景区,是否有景区编号
	 */
	@SuppressLint("NewApi")
	public void checkScenicId() {

		scenicId = sp.getString("scenicId", "");
		scenicName = sp.getString("scenicName", "");
		System.out.println(scenicId);
		if (scenicId.trim().isEmpty()) {
			// isready = false;
			scenicName_textView.setText("请选择景区");
			alertDialog.show();
		} else {
			// isready = true;
			scenicName_textView.setText(scenicName);
			scenicChoose_button.setText("修改景区");
		}
	}

	private AlertDialog alertDialog;

	/**
	 * 显示选择景区对话框
	 */
	public AlertDialog showChooseDialog() {
		AlertDialog.Builder builder = new Builder(MainActivity.this);
		builder.setMessage("首次使用必须选择景区!,否则无法正常使用");

		builder.setTitle("请选择景区");

		builder.setPositiveButton("选择景区",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						startChooseScenic();
					}

				});

		builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});

		alertDialog = builder.create();
		return alertDialog;
	}

	/**
	 * 显示时获取当前日期
	 */
	@Override
	public void onStart() {
		super.onStart();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd  EEEE",
				Locale.CHINA);
		Date curDate = new Date(System.currentTimeMillis());// 获取当前时间
		txtDate.setText(formatter.format(curDate));

	}

	@Override
	public void onStop() {
		super.onStop();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (reader != null) {
			reader.close();
		}
	}

	/**
	 * 更新界面的handler线程
	 * 
	 * @author 袁东亮
	 * 
	 */
	WeakReference<MainActivity> outerClass;

	private class MyHandler extends Handler {

		@SuppressLint("HandlerLeak")
		MyHandler(MainActivity activity) {
			outerClass = new WeakReference<MainActivity>(activity);
		}

		@SuppressLint("ShowToast")
		@Override
		public void handleMessage(Message msg) {
			final MainActivity theClass = outerClass.get();
			switch (msg.what) {
			case 1:
				// theClass.pd.dismiss(); // 关闭ProgressDialog
				// theClass.btnQuery.setEnabled(true);
				if (theClass.bSuccess) {
					String uid = String.format("%08X", theClass.reader.uid);
					theClass.passportId_textView.setText(uid);
					if (uid != null) {
						String sData = "";
						for (int i = 0; i < 5; i++) {
							Data2_0[i] = theClass.data[i];
							// sData += String.valueOf(data[i]);
							sData += String.format("%02X",
									(byte) theClass.data[i]).trim();
						}
						passportId_textView.setText(sData.trim());
						// sData = "";
						for (int i = 16; i < 32; i++) {
							sData += String.format("%02x ",
									(byte) theClass.data[i]);
						}
						// theClass.IDNumber_textView.setText(sData);
						for (int i = 0; i < 16; i++) {
							sData += String.format("%02x ",
									(byte) theClass.block3_data[i]);
						}
						// theClass.phoneNumber_textView.setText(sData);
						sData = "";
						// authentication = new
						// Authentication(MainActivity.this);
						passportId = passportId_textView.getText().toString();
						// ////////////////////////访问网络验证数据/////////////////////////////////////
						// if (authentication.AuthenticationPassPortState(
						// scenicId, passportId) == 0) {
						// UUID uuid = UUID.randomUUID();//UUID生成

						// Toast.makeText(context, "手机中无该护照编号的用户，正在联网络查询",
						// Toast.LENGTH_LONG).show();
						String url = RequestURl.AuthenticationURL;
						RequestParams requestParams = new RequestParams();
						requestParams.put("viewSpotCode", scenicId);
						requestParams.put("clientCode", "ar");
						requestParams.put("passportCode", passportId);
						AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
						asyncHttpClient.setTimeout(20000);
						asyncHttpClient.post(MainActivity.this, url,
								requestParams,
								new AuthenticationAsyncHttpResponseHandler());
						// } else if
						// (authentication.AuthenticationPassPortState(
						// scenicId, passportId) == 1) {

						// }

						// /////////////////////////////////////////////////////////////////
					}
				} else {
					Toast.makeText(theClass, theClass.cMsg, Toast.LENGTH_SHORT)
							.show();
				}
				break;

			case 11:
				passportId_textView.setText("");
				name_textView.setText("");
				phoneNumber_textView.setText("");
				IDNumber_textView.setText("");
				passportState_textView.setText("");
				integral_textView.setText("");
				dctextView.setText("");
				activate_button.setVisibility(View.INVISIBLE);
				pd = ProgressDialog.show(MainActivity.this, "", "正在读取数据...");
				break;
			case 12:

				// passportState_textView.setText("");
				// passportId_textView.setText("");
				// name_textView.setText("");
				// phoneNumber_textView.setText("");
				// IDNumber_textView.setText("");

				// txtBlock1.setText("");
				// txtBlock2.setText("");
				// pd = ProgressDialog.show(MainActivity.this, "", "开启标签识别...");
				break;
			case 14:
				alertDialog.show();
				break;

			}

		}
	};

	// 护照状态,0-未激活，1-正常，2-过期，3-禁用，5-一个护照在一个景区一天只能使用一次，9-假护照
	// uc：用户编码ic：身份证号rn:真实姓名ph:电话
	/**
	 * 用户验证访问网络handler
	 * 
	 * @author 袁东亮
	 * 
	 */
	private class AuthenticationAsyncHttpResponseHandler extends
			AsyncHttpResponseHandler {

		@Override
		@Deprecated
		public void onFailure(int statusCode, Throwable error, String content) {
			super.onFailure(statusCode, error, content);
			Toast.makeText(context,
					"访问网络出错！错误代码:" + statusCode + "请检查网络或稍后再试！",
					Toast.LENGTH_LONG).show();
		}

		@Override
		public void onFinish() {
			isready = true;
			Uri notification = RingtoneManager
					.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
			Ringtone r = RingtoneManager.getRingtone(getApplicationContext(),
					notification);
			r.play();
			if (pd != null) {
				pd.dismiss();
			}
		}

		@Override
		public void onStart() {
			isready = false;
			pd.setMessage("正在联网验证数据...");
			// ProgressDialog.show(MainActivity.this,
			// "", "正在联网验证数据...");
		}

		@Override
		@Deprecated
		public void onSuccess(int statusCode, Header[] headers, String content) {
			super.onSuccess(statusCode, headers, content);
			try {
				JSONObject jsonObject = new JSONObject(content);
				int state = jsonObject.getInt("s");
				System.out.println(state);
				Uri notification = RingtoneManager
						.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
				Ringtone r = RingtoneManager.getRingtone(
						getApplicationContext(), notification);
				r.play();
				name_textView.setText("");
				phoneNumber_textView.setText("");
				IDNumber_textView.setText("");
				switch (state) {
				case 0: {
					responseResult = "未激活";
					passportState_textView.setText("未激活");
					activate_button.setVisibility(View.VISIBLE);
					activate_button
							.setOnClickListener(new ActiveOnClickListener());
				}
					break;
				case 1: {
					responseResult = "正常";

					if (pd != null) {
						pd.dismiss();
					}
					Tourist t = new Tourist();
					t.setName(jsonObject.getString("rn"));
					t.setPhoneNumber(jsonObject.getString("ph"));
					t.setIDNumber(jsonObject.getString("ic"));
					t.setIntegral(jsonObject.getString("jf"));
					t.setDc(jsonObject.getInt("dc"));
					passportState_textView.setText("正常");
					name_textView.setText(t.getName());
					phoneNumber_textView.setText(t.getPhoneNumber());
					IDNumber_textView.setText(t.getIDNumber());
					integral_textView.setText(t.getIntegral());
					activate_button.setVisibility(View.INVISIBLE);
					String dc = "";
					if (t.getDc() == 0) {
						dc = "免费";
					} else if (t.getDc() == 10) {
						dc = "全价";
					} else {
						dc = t.getDc() + "折";
					}
					dctextView.setText(dc);
				}
					break;
				case 2: {
					responseResult = "过期";
					passportState_textView.setText("过期");
					activate_button.setVisibility(View.INVISIBLE);
				}
					break;
				case 3: {
					responseResult = "禁用";
					passportState_textView.setText("禁用");
					activate_button.setVisibility(View.INVISIBLE);
				}
					break;
				case 5: {
					responseResult = "一个护照在一个景区一天只能使用一次";
					passportState_textView.setText("一个护照在一个景区一天只能使用一次");
					activate_button.setVisibility(View.INVISIBLE);
				}

					break;

				case 6: {
					responseResult = "锁定";
					passportState_textView.setText("锁定");
					activate_button.setVisibility(View.INVISIBLE);
				}

					break;
				case 9: {
					responseResult = "假护照";
					passportState_textView.setText("假护照");
					activate_button.setVisibility(View.INVISIBLE);
				}
					break;
				case 20: {
					passportState_textView.setText("电话重复");
					activate_button.setVisibility(View.INVISIBLE);
					responseResult = "电话重复";

				}
					break;
				case 21: {
					responseResult = "email重复";
					passportState_textView.setText("email重复");
					activate_button.setVisibility(View.INVISIBLE);

				}
					break;
				case 22: {
					passportState_textView.setText("身份证重复");
					activate_button.setVisibility(View.INVISIBLE);
					responseResult = "身份证重复";

				}
					break;
				case 23: {
					passportState_textView.setText("请填写正确的护照编号！");
					activate_button.setVisibility(View.INVISIBLE);
					responseResult = "请填写正确的护照编号！";
				}
					break;
				case 24: {
					passportState_textView.setText("该护照已激活！");
					activate_button.setVisibility(View.INVISIBLE);
					responseResult = "该护照已激活！9";
				}
					break;
				case 25: {
					passportState_textView.setText(" ");
					activate_button.setVisibility(View.INVISIBLE);
					responseResult = "验证码错误！";
				}
					break;
				case 99: {
					passportState_textView.setText("未知错误99");
					activate_button.setVisibility(View.INVISIBLE);
					responseResult = "未知错误99";
				}
					break;
				}

			} catch (JSONException e) {
				e.printStackTrace();
				responseResult = "服务器相应数据无法解析：" + content;
			} finally {
				Toast toast = new Toast(context);
				toast.setGravity(Gravity.CENTER, 0, 0);
				TextView textView = new TextView(context);
				textView.setBackgroundResource(R.drawable.toast_bg);
				textView.setText(responseResult);
				toast.setView(textView);
				toast.show();

			}
		}
	}

	/**
	 * 护照激活事件
	 * 
	 * @author 袁东亮
	 * 
	 */
	private class ActiveOnClickListener implements OnClickListener {

		@Override
		public void onClick(View v) {

			Intent intent = new Intent(context, ActiveActivity.class);
			intent.putExtra("passportId", passportId);
			intent.putExtra("scenicId", scenicId);
			startActivityForResult(intent, RequestCode.ACTIVE_PASSPORT_RESULT);

			// String url = RequestURl.ActiveURL;
			// RequestParams requestParams = new RequestParams();
			// requestParams.put("viewSpotCode", scenicId);
			// requestParams.put("clientCode", "ar");
			// requestParams.put("passportCode", passportId);
			// AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
			// asyncHttpClient.setTimeout(20000);
			// asyncHttpClient.post(MainActivity.this, url, requestParams,
			// new ActiveAsyncHttpResponseHandler());

		}
	}

	/**
	 * 写标签数据事件
	 * 
	 * @author 袁东亮
	 * 
	 */
	@SuppressWarnings("unused")
	private class btnwritr_OnClick implements OnClickListener {

		@Override
		public void onClick(View v) {
			new Thread() {
				public void run() {
					byte d[] = new byte[16];
					for (int i = 0; i < 16; i++) {
						d[i] = (byte) i;
					}
					int ret = -1;
					try {
						ret = reader.tagWriteData((byte) 0, d);
						if (ret == 0) {
							if (ret == 0) {
								bSuccess = true;

							} else if (ret > 9) {
								cMsg = "写标签块数据失败。";
							}
						}
					} catch (Exception e) {
						cMsg = "未知错误，请联系供应商。";
						bSuccess = false;
					}

					handler.sendEmptyMessage(1);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				};
			}.start();

		}

	}

	// 查询按钮事件
	@SuppressWarnings("unused")
	private class btnQuery_Click implements android.view.View.OnClickListener {
		public void onClick(View v) {
			// btnQuery.setEnabled(false);

			new AutoQureTag().start();
			// qureTag();

		}
	}

	/**
	 * 自动读取标签数据的线程
	 * 
	 * @author 袁东亮
	 * 
	 */
	private class AutoQureTag extends Thread {
		@Override
		public void run() {
			while (true) {
				if (isready) {// 查看设备是否链接
					if (scenicId == null || scenicId.trim().isEmpty()) {// 是否选择了景区编号
						if (!alertDialog.isShowing()) {// 选择景区对话框是否显示了
							handler.sendEmptyMessage(14);
						}
					} else {
						if (pd != null) {
							pd.dismiss();
						}
						handler.sendEmptyMessage(12);
						try {
							cMsg = "与设备通讯失败，请确认是否插好！";
							bSuccess = false;
							int ret = reader.readTag();
							if (ret == 0) {
								ret = reader.getTagUID();
								if (ret == 0 && reader.uid == 0)
									ret = 9;
								else {
									handler.sendEmptyMessage(11);
									if (ret == 0) {
										byte pwds[] = new byte[6];
										for (int i = 0; i < 6; i++) {
											pwds[i] = (byte) 0xFF;
										}
										ret = reader.tagReadBlockData((byte) 2,
												(byte) 0, (byte) 3, (byte) 0,
												pwds, data);
										ret = reader.tagReadData((byte) 0,
												block3_data);

										// ret = reader
										// .tagAuthenticate((byte) 2,
										// data);
										// if (ret == 0) {
										// for (int i = 0; i < 16; i++)
										// {
										// data[i] = (byte) i;
										// }
										// ret =
										// reader.tagWriteData((byte)
										// 0,
										// data);
										// if (ret == 0)
										// ret =
										// reader.tagReadData((byte)
										// 0,
										// data);
										// }
										if (ret == 0) {
											bSuccess = true;
										} else if (ret > 9) {
											cMsg = "读取标签块数据失败。";
										}
									} else if (ret == 9) {
										cMsg = "未能识别标签，请将设备前端靠近标签。";
									}
								}
							} else if (ret == -1) {
								cMsg = "设备电量不足，请充电！";
							}
						} catch (Exception e) {
							cMsg = "未知错误，请联系供应商。";
							bSuccess = false;
						} finally {
						}
						handler.sendEmptyMessage(1);
						try {
							AutoQureTag.sleep(3000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}

		}
	}

	@Override
	public void onConnect(String arg0) {
		// scenicId.setText("SN:" + arg0);
	}

	@Override
	public void onDisconnect() {
		// TODO Auto-generated method stub

	}

	/**
	 * NFC刷卡器状态改变监听器
	 * 
	 * @param NFC双卡器状态
	 */
	@Override
	public void onStatusChange(IvrJackStatus arg0) {

		System.out.println("onStatusChange" + arg0);
		switch (arg0) {
		case ijsDetecting:
			pd = ProgressDialog.show(MainActivity.this, "", "正在识别设备...");
			break;

		case ijsRecognized:
			if (pd != null) {
				pd.dismiss();
			}
			passport_state_relativilayout.setVisibility(View.VISIBLE);
			passport_info_relativelLayout.setVisibility(View.VISIBLE);
			// passportId_textView.setText("");
			// txtBlock1.setText("");
			// txtBlock2.setText("");
			imgPlugout.setVisibility(View.GONE);
			name_label.setVisibility(View.VISIBLE);
			name_textView.setVisibility(View.VISIBLE);
			// scenicId.setVisibility(View.VISIBLE);
			passportId_label.setVisibility(View.VISIBLE);
			phoneNumber_label.setVisibility(View.VISIBLE);
			phoneNumber_textView.setVisibility(View.VISIBLE);
			passportId_textView.setVisibility(View.VISIBLE);
			IDNumber_label.setVisibility(View.VISIBLE);
			IDNumber_textView.setVisibility(View.VISIBLE);
			passportState_label.setVisibility(View.VISIBLE);
			passportState_textView.setVisibility(View.VISIBLE);
			integral_label.setVisibility(View.VISIBLE);
			integral_textView.setVisibility(View.VISIBLE);
			// chkReadBlock.setVisibility(View.VISIBLE);
			txtStatus.setText("欢迎使用");
			// btnQuery.setEnabled(true);
			Toast.makeText(this, "设备已识别。", Toast.LENGTH_SHORT).show();
			isready = true;

			if (!autoQureTag.isAlive()) {
				autoQureTag.start();
			}

			Toast.makeText(MainActivity.this, "开始标签识别...", Toast.LENGTH_LONG)
					.show();
			break;

		case ijsUnRecognized:
			pd.dismiss();

			Toast.makeText(this, "设备未能识别，请重新插拔或重启应用程序再试！", Toast.LENGTH_SHORT)
					.show();
			break;

		case ijsPlugout:

			txtStatus.setText("您没有连接设备！");
			passport_state_relativilayout.setVisibility(View.INVISIBLE);
			passport_info_relativelLayout.setVisibility(View.INVISIBLE);
			imgPlugout.setVisibility(View.VISIBLE);
			name_label.setVisibility(View.INVISIBLE);
			name_textView.setVisibility(View.INVISIBLE);
			passportId_label.setVisibility(View.INVISIBLE);
			phoneNumber_label.setVisibility(View.INVISIBLE);
			IDNumber_label.setVisibility(View.INVISIBLE);
			passportId_textView.setVisibility(View.INVISIBLE);
			phoneNumber_textView.setVisibility(View.INVISIBLE);
			IDNumber_textView.setVisibility(View.INVISIBLE);
			passportState_label.setVisibility(View.INVISIBLE);
			passportState_textView.setVisibility(View.INVISIBLE);
			integral_label.setVisibility(View.INVISIBLE);
			integral_textView.setVisibility(View.INVISIBLE);
			Toast.makeText(this, "设备已拨出。", Toast.LENGTH_SHORT).show();
			if (pd != null) {
				pd.dismiss();
			}
			isready = false;
			break;
		}
	}

	/**
	 * 请求跳转后获得返回的结果
	 * 
	 * @param requestCode请求码
	 * @param resultCode结果码
	 * @param data返回的数据
	 */
	@SuppressLint("NewApi")
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		System.out.println("requestCode--------------------------"
				+ requestCode);
		if (data != null) {
			// Check which request we're responding to
			switch (requestCode) {
			case 1: {

				scenicId = data.getExtras().getString("scenicId");
				scenicName = data.getExtras().getString("scenicName");
				if (!(scenicName.trim().isEmpty())
						&& !(scenicId.trim().isEmpty())) {
					scenicName_textView.setText(scenicName);
					scenicChoose_button.setText("修改景区");
					Editor editor = sp.edit();
					editor.putString("scenicId", scenicId);
					editor.putString("scenicName", scenicName);
					editor.commit();
					if (alertDialog != null) {
						alertDialog.dismiss();
					}
				}
			}
				break;

			case 2: {
				System.out.println("RequestCode.ACTIVE_PASSPORT_RESULT");
				passportState_textView.setText("正常");
				name_textView.setText(data.getExtras().getString("name"));
				phoneNumber_textView.setText(data.getExtras().getString(
						"phone_number"));
				IDNumber_textView.setText(data.getExtras()
						.getString("IDNumber"));
				System.out.println("data.getExtras().getString(jf)main"
						+ data.getExtras().getString("jf"));
				integral_textView.setText(data.getExtras().getInt("jf") + "");
				int _dc = data.getExtras().getInt("dc");
				String dc = "";
				if (_dc == 0) {
					dc = "免费";
				} else if (_dc == 10) {
					dc = "全价";
				} else {
					dc = _dc + "折";
				}
				dctextView.setText(dc);

				activate_button.setVisibility(View.INVISIBLE);
			}
				break;
			}
		}

	}

	@Override
	public void onClick(View v) {
		startChooseScenic();
	}

	/**
	 * 跳转至选择景区界面(待结果的跳转)
	 */
	public void startChooseScenic() {
		Intent intent = new Intent(this, SicenicSetting.class);
		startActivityForResult(intent, RequestCode.SETTING_SCENIC_RESULT);
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) { // 获取
																				// back键

			if (menu_display) { // 如果 Menu已经打开 ，先关闭Menu
				menuWindow.dismiss();
				menu_display = false;
			} else {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, Exit.class);
				startActivity(intent);
			}
		}

		else if (keyCode == KeyEvent.KEYCODE_MENU) { // 获取 Menu键
			if (!menu_display) {
				// 获取LayoutInflater实例
				inflater = (LayoutInflater) this
						.getSystemService(LAYOUT_INFLATER_SERVICE);
				// 这里的main布局是在inflate中加入的哦，以前都是直接this.setContentView()的吧？呵呵
				// 该方法返回的是一个View的对象，是布局中的根
				layout = inflater.inflate(R.layout.main_menu, null);

				// 下面我们要考虑了，我怎样将我的layout加入到PopupWindow中呢？？？很简单
				menuWindow = new PopupWindow(layout, LayoutParams.FILL_PARENT,
						LayoutParams.WRAP_CONTENT); // 后两个参数是width和height
				// menuWindow.showAsDropDown(layout); //设置弹出效果
				// menuWindow.showAsDropDown(null, 0, layout.getHeight());
				menuWindow.showAtLocation(
						this.findViewById(R.id.main_RelativeLayout),
						Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0); // 设置layout在PopupWindow中显示的位置
				// 如何获取我们main中的控件呢？也很简单
				mClose = (LinearLayout) layout.findViewById(R.id.menu_close);
				mCloseBtn = (LinearLayout) layout
						.findViewById(R.id.menu_close_btn);

				// 下面对每一个Layout进行单击事件的注册吧。。。
				// 比如单击某个MenuItem的时候，他的背景色改变
				// 事先准备好一些背景图片或者颜色
				mCloseBtn.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View arg0) {
						// Toast.makeText(Main.this, "退出",
						// Toast.LENGTH_LONG).show();
						Intent intent = new Intent();
						intent.setClass(MainActivity.this, Exit.class);
						startActivity(intent);
						menuWindow.dismiss(); // 响应点击事件之后关闭Menu
					}
				});
				menu_display = true;
			} else {
				// 如果当前已经为显示状态，则隐藏起来
				menuWindow.dismiss();
				menu_display = false;
			}

			return false;
		}
		return false;
	}
}
