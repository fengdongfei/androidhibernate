package com.hkcts.passportsearch.dao;

import com.hkcts.passportsearch.model.gzl_passport;
import com.ydl.ahibernate.dao.BaseDao;

public interface gzl_passportDao extends BaseDao<gzl_passport> {
}
