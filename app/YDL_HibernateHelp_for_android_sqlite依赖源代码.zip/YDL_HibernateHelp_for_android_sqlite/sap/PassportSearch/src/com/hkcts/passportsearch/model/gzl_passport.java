package com.hkcts.passportsearch.model;

import com.ydl.ahibernate.annotation.Column;
import com.ydl.ahibernate.annotation.Id;
import com.ydl.ahibernate.annotation.Table;

//此处没有加Table属性,它是其他类的基类,本类中用@Column注解的字段在子类中同样会被创建到表中.
@Table(name = "gzl_passport")
public class gzl_passport {
	@Id
	@Column(name = "id")
	private int id; // 主键,int类型,数据库建表时此字段会设为自增长

	@Column(name = "passportCode", length = 50)
	private String passportCode; // 护照编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "passportChipCode", length = 50)
	private String passportChipCode; // 护照芯片编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "passportOpenTime", length = 50)
	private String passportOpenTime; // 名字长度一般不会超过20个字符吧,length=20数据字段的长度是20
	@Column(name = "passportCloseTime", length = 50)
	private String passportCloseTime; // 名字长度一般不会超过20个字符吧,length=20数据字段的长度是20

	@Column(name = "passportUserdNum", type = "INTEGER")
	private int passportUserdNum; // 年龄一般是数值,用type = "INTEGER"规范一下吧.

	@Column(name = "status", length = 10)
	private String status; // 护照编号长度一般不会超过50个字符吧,length=20数据字段的长度是20
	@Column(name = "userCode", length = 50)
	private String userCode; // 护照编号长度一般不会超过50个字符吧,length=20数据字段的长度是20

	// //假设您开始时没有此属性,程序开发中才想到此属性,去掉代码注释试试吧,数据库增删改查不用修改任何代码哦.
	// @Column(name = "sex")
	// private String sex;

	// // 有些字段您可能不希望保存到数据库中,不用@Column注释就不会映射到数据库.
	// private String noSaveFild;

	public int getId() {
		return id;
	}

	/**
	 * @return the passportCode
	 */
	public String getPassportCode() {
		return passportCode;
	}

	/**
	 * @param passportCode
	 *            the passportCode to set
	 */
	public void setPassportCode(String passportCode) {
		this.passportCode = passportCode;
	}

	/**
	 * @return the passportChipCode
	 */
	public String getPassportChipCode() {
		return passportChipCode;
	}

	/**
	 * @param passportChipCode
	 *            the passportChipCode to set
	 */
	public void setPassportChipCode(String passportChipCode) {
		this.passportChipCode = passportChipCode;
	}

	/**
	 * @return the passportOpenTime
	 */
	public String getPassportOpenTime() {
		return passportOpenTime;
	}

	/**
	 * @param passportOpenTime
	 *            the passportOpenTime to set
	 */
	public void setPassportOpenTime(String passportOpenTime) {
		this.passportOpenTime = passportOpenTime;
	}

	/**
	 * @return the passportCloseTime
	 */
	public String getPassportCloseTime() {
		return passportCloseTime;
	}

	/**
	 * @param passportCloseTime
	 *            the passportCloseTime to set
	 */
	public void setPassportCloseTime(String passportCloseTime) {
		this.passportCloseTime = passportCloseTime;
	}

	/**
	 * @return the passportUserdNum
	 */
	public int getPassportUserdNum() {
		return passportUserdNum;
	}

	/**
	 * @param passportUserdNum
	 *            the passportUserdNum to set
	 */
	public void setPassportUserdNum(int passportUserdNum) {
		this.passportUserdNum = passportUserdNum;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode
	 *            the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public void setId(int id) {
		this.id = id;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "gzl_passport [id=" + id + ", passportCode=" + passportCode
				+ ", passportChipCode=" + passportChipCode
				+ ", passportOpenTime=" + passportOpenTime
				+ ", passportCloseTime=" + passportCloseTime
				+ ", passportUserdNum=" + passportUserdNum + ", status="
				+ status + ", userCode=" + userCode + "]";
	}

}
