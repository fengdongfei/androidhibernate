package com.hkcts.passportsearch.config;

public class RequestCode {
	public static int SETTING_SCENIC_RESULT = 1;
	public static int ACTIVE_PASSPORT_RESULT = 2;

	public RequestCode() {
		// TODO Auto-generated constructor stub
	}

}
