package com.hkcts.passportsearch.config;

public class RequestURl {

	public RequestURl() {
	}

	public static String AuthenticationURL = "http://192.168.0.20:85/gs/vv.jsp";
	public static String ActiveURL = "http://192.168.0.20:85/gs/vvOpen.jsp";
	public static String GetScenicURL = "http://192.168.0.20:85/gs/spots.jsp";
	public static String AutoUpdate = "http://192.168.0.20:85/gs/";
}
