package com.hkcts.passportsearch.bean;

/**
 * 封装景区信息的类
 * 
 * @author 袁东亮
 * 
 */
public class Scenic {
	private String scenicName;
	private String scenicId;

	public String getScenicName() {
		return scenicName;
	}

	public void setScenicName(String scenicName) {
		this.scenicName = scenicName;
	}

	public String getScenicId() {
		return scenicId;
	}

	public void setScenicId(String scenicId) {
		this.scenicId = scenicId;
	}

	public Scenic() {
	}

}
