package com.hkcts.passportsearch.activity;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.hkcts.passportsearch.R;
import com.hkcts.passportsearch.config.RequestURl;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

public class ActiveActivity extends Activity {
	private TextView passportId_textView;
	private String passportId;
	private Button backButton;
	private Button acviteButton;
	private Button cancerButton;

	private String name;
	private String IDNumber;
	private String phone_number;
	private String email;
	private String password;
	private String verificationCode;
	private EditText name_textView;
	private EditText IDNumbe_textViewr;
	private EditText phone_number_textView;
	private EditText email_textView;
	private EditText password_textView;
	private EditText verificationCode_EditText;
	private String scenicId;
	private Context context;

	public ActiveActivity() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.active);
		context = this;
		Intent intent = this.getIntent();
		backButton = (Button) findViewById(R.id.back_button);
		acviteButton = (Button) findViewById(R.id.acvite_button);
		cancerButton = (Button) findViewById(R.id.cancer_button);
		backButton.setOnClickListener(new BackOnclickListener());
		cancerButton.setOnClickListener(new BackOnclickListener());

		passportId = intent.getStringExtra("passportId");
		scenicId = intent.getStringExtra("scenicId");
		passportId_textView = (TextView) findViewById(R.id.passportId_textView);
		passportId_textView.setText(passportId);

		name_textView = (EditText) findViewById(R.id.name_editText);
		IDNumbe_textViewr = (EditText) findViewById(R.id.IdCard_EditText);
		phone_number_textView = (EditText) findViewById(R.id.phone_Number_EditText);
		email_textView = (EditText) findViewById(R.id.email_EditText);
		password_textView = (EditText) findViewById(R.id.password_editText);
		verificationCode_EditText = (EditText) findViewById(R.id.verificationCode_EditText);

		acviteButton.setOnClickListener(new ActiveOnclickListner());

	}

	private class ActiveOnclickListner implements OnClickListener {

		@Override
		public void onClick(View v) {

			name = name_textView.getText().toString();
			IDNumber = IDNumbe_textViewr.getText().toString();
			phone_number = phone_number_textView.getText().toString();
			email = email_textView.getText().toString();
			password = password_textView.getText().toString();
			verificationCode = verificationCode_EditText.getText().toString();

			String url = RequestURl.ActiveURL;
			RequestParams requestParams = new RequestParams();
			requestParams.put("viewSpotCode", scenicId);
			requestParams.put("clientCode", "ar");
			requestParams.put("passportCode", passportId);
			requestParams.put("realName", name);
			requestParams.put("idCard", IDNumber);
			requestParams.put("phone", phone_number);
			requestParams.put("mailbox", email);
			requestParams.put("password", password);
			requestParams.put("verify", verificationCode);
			AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
			asyncHttpClient.post(ActiveActivity.this, url, requestParams,
					new ActiveAsyncHttpResponseHandler());
		}

	}

	private class ActiveAsyncHttpResponseHandler extends
			AsyncHttpResponseHandler {

		/*
		 * (non-Javadoc)
		 * 
		 * @see com.loopj.android.http.AsyncHttpResponseHandler#onFailure(int,
		 * java.lang.Throwable, java.lang.String)
		 */
		@Override
		@Deprecated
		public void onFailure(int statusCode, Throwable error, String content) {
			// TODO Auto-generated method stub
			super.onFailure(statusCode, error, content);
			Toast.makeText(ActiveActivity.this, "访问服务器出错，错误码：" + statusCode,
					Toast.LENGTH_LONG).show();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see com.loopj.android.http.AsyncHttpResponseHandler#onFinish()
		 */
		@Override
		public void onFinish() {
			// TODO Auto-generated method stub
			super.onFinish();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see com.loopj.android.http.AsyncHttpResponseHandler#onStart()
		 */
		@Override
		public void onStart() {
			// TODO Auto-generated method stub
			super.onStart();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see com.loopj.android.http.AsyncHttpResponseHandler#onSuccess(int,
		 * java.lang.String)
		 */

		String responseResult;

		@Override
		@Deprecated
		public void onSuccess(int statusCode, String content) {
			// TODO Auto-generated method stub
			super.onSuccess(statusCode, content);
			try {

				JSONObject jsonObject = new JSONObject(content);
				int state = jsonObject.getInt("s");
				Uri notification = RingtoneManager
						.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
				Ringtone r = RingtoneManager.getRingtone(
						getApplicationContext(), notification);
				r.play();
				switch (state) {
				case 0: {
					responseResult = "未激活";
				}
					break;
				case 1: {
					responseResult = "激活成功";
					int jf = jsonObject.getInt("jf");
					int dc = jsonObject.getInt("dc");
					System.out.println("active" + jf);
					Intent intent = new Intent();
					intent.putExtra("name", name);
					intent.putExtra("IDNumber", IDNumber);
					intent.putExtra("phone_number", phone_number);
					intent.putExtra("jf", jf);
					intent.putExtra("dc", dc);
					ActiveActivity.this.setResult(RESULT_OK, intent);
					ActiveActivity.this.finish();

				}
					break;
				case 2: {
					responseResult = "过期";
				}
					break;
				case 3: {
					responseResult = "禁用";

				}
					break;
				case 5: {
					responseResult = "一个护照在一个景区一天只能使用一次";

				}
					break;

				case 6: {
					responseResult = "锁定";
				}

				case 9: {
					responseResult = "假护照";

				}
					break;
				case 20: {
					responseResult = "电话重复";

				}
					break;
				case 21: {
					responseResult = "email重复";

				}
					break;
				case 22: {
					responseResult = "身份证重复";

				}
					break;
				case 23: {
					responseResult = "请填写正确的护照编号！";
				}
					break;
				case 24: {
					responseResult = "该护照已激活！9";
				}
					break;
				case 25: {
					
					responseResult = "验证码错误！";
				}
					break;
				case 99: {
					responseResult = "未知错误99";
				}
					break;

				}

			} catch (JSONException e) {
				e.printStackTrace();
				responseResult = "服务器相应数据无法解析：" + content;
			} finally {
				Toast toast = new Toast(context);
				toast.setGravity(Gravity.CENTER, 0, 0);
				TextView textView = new TextView(context);
				textView.setBackgroundResource(R.drawable.toast_bg);
				textView.setText(responseResult);
				toast.setView(textView);
				toast.show();
			}
		}

	}

	private class BackOnclickListener implements OnClickListener {

		@Override
		public void onClick(View v) {
			ActiveActivity.this.finish();

		}
	}
}
