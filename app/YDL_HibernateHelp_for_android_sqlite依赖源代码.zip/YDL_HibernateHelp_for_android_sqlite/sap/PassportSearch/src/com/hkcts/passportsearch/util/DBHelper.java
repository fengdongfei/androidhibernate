package com.hkcts.passportsearch.util;

import android.content.Context;

import com.hkcts.passportsearch.model.gzl_passport;
import com.hkcts.passportsearch.model.gzl_passport_recording;
import com.hkcts.passportsearch.model.gzl_user;
import com.ydl.ahibernate.util.MyDBHelper;

public class DBHelper extends MyDBHelper {
	private static final String DBNAME = "dy_gzl.db";
	private static final int DBVERSION = 1;
	private static final Class<?>[] clazz = { gzl_passport.class,
			gzl_user.class, gzl_passport_recording.class };//

	public DBHelper(Context context) {
		super(context, DBNAME, null, DBVERSION, clazz);
	}

}
