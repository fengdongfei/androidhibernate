package com.tgb.lk.demo.dao.impl;

import com.tgb.lk.demo.model.Teacher;
import com.tgb.lk.demo.util.DBHelper;
import com.ydl.ahibernate.dao.impl.BaseDaoImpl;

import android.content.Context;

public class TeacherDaoImpl extends BaseDaoImpl<Teacher> {
	public TeacherDaoImpl(Context context) {
		super(new DBHelper(context));
	}
}
