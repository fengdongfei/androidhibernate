package com.tgb.lk.demo.dao;

import com.tgb.lk.demo.model.Student;
import com.ydl.ahibernate.dao.BaseDao;

public interface StudentDao extends BaseDao<Student> {
}
