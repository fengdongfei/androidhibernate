package com.tgb.lk.demo.dao;

import com.tgb.lk.demo.model.Teacher;
import com.ydl.ahibernate.dao.BaseDao;

public interface TeacherDao extends BaseDao<Teacher> {

}
